// Valley Freight — shared UI script
(function () {
  const path = location.pathname.split("/").pop() || "index.html";

  // Inject nav + footer
  const navMarkup = `
    <nav class="nav" id="nav">
      <div class="nav-inner">
        <a href="index.html" class="brand"><span class="brand-mark"></span> Valley Freight</a>
        <div class="nav-links">
          <a href="index.html" data-key="index.html">Home</a>
          <a href="services.html" data-key="services.html">Services</a>
          <a href="about.html" data-key="about.html">About</a>
          <a href="contact.html" data-key="contact.html">Contact</a>
        </div>
        <a href="contact.html" class="nav-cta">Get a Quote</a>
        <button class="burger" id="burger" aria-label="Open menu">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
        </button>
      </div>
    </nav>
    <div class="mobile-menu" id="mobileMenu">
      <button class="mobile-close" id="mobileClose" aria-label="Close menu">×</button>
      <a href="index.html">Home</a>
      <a href="services.html">Services</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
    </div>
  `;

  const footerMarkup = `
    <footer>
      <div class="container">
        <div class="footer-grid">
          <div class="brand-block">
            <a href="index.html" class="brand" style="color:#fff"><span class="brand-mark"></span> Valley Freight</a>
            <p>Zimbabwean private limited company — customs clearing, freight forwarding, transport, sea and air freight across Southern Africa.</p>
          </div>
          <div>
            <h4>Sitemap</h4>
            <ul>
              <li><a href="index.html">Home</a></li>
              <li><a href="services.html">Services</a></li>
              <li><a href="about.html">About</a></li>
              <li><a href="contact.html">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4>Head Office</h4>
            <ul>
              <li>Office No.3 Terricave Complex,<br/>529 Great North Rd, Beitbridge</li>
              <li><a href="tel:+263852323926">+263 852 323 926</a></li>
              <li><a href="mailto:info@valleyfreight.co.zw">info@valleyfreight.co.zw</a></li>
            </ul>
          </div>
        </div>
        <div class="bottom">
          <span>© 2025 Valley Freight. All rights reserved.</span>
          <span>Southern African Logistics</span>
        </div>
      </div>
    </footer>
  `;

  document.body.insertAdjacentHTML("afterbegin", navMarkup);
  document.body.insertAdjacentHTML("beforeend", footerMarkup);

  // Active nav link
  document.querySelectorAll(".nav-links a").forEach((a) => {
    if (a.dataset.key === path) a.classList.add("active");
  });

  // Sticky nav bg on scroll
  const nav = document.getElementById("nav");
  const onScroll = () => nav.classList.toggle("scrolled", window.scrollY > 40);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  // Mobile menu
  const menu = document.getElementById("mobileMenu");
  document.getElementById("burger").addEventListener("click", () => menu.classList.add("open"));
  document.getElementById("mobileClose").addEventListener("click", () => menu.classList.remove("open"));
  menu.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => menu.classList.remove("open")));

  // Reveal on scroll
  const io = new IntersectionObserver(
    (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
    { threshold: 0.12 }
  );
  document.querySelectorAll(".reveal").forEach((el) => io.observe(el));

  // Contact form
  const form = document.getElementById("contactForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      form.style.display = "none";
      document.getElementById("formSuccess").style.display = "grid";
    });
    const again = document.getElementById("sendAgain");
    if (again)
      again.addEventListener("click", () => {
        form.reset();
        form.style.display = "block";
        document.getElementById("formSuccess").style.display = "none";
      });
  }
})();
